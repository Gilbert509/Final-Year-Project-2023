This project in order to running it you must downlooad all libraries needed or found in codes 
after you have to  setting wifi in your code and also upload code to nodeMCU 